#include <iostream> 
#include "sqlite3.h"  
#pragma comment(lib, "sqlite3.lib") 

using namespace std;

int main() {
	sqlite3 * db;
	int res = sqlite3_open("test.db", &db);
	if (res != SQLITE_OK) {
		cout << "fail!" << sqlite3_errmsg(db) << endl;
		return 0;
	}
	else {
		cout << "success" << endl;
	}

	const char * sql = "CREATE TABLE COMPANY("  \
		"ID INT PRIMARY KEY     NOT NULL," \
		"NAME           TEXT    NOT NULL," \
		"AGE            INT     NOT NULL," \
		"ADDRESS        CHAR(50)," \
		"SALARY         REAL );";
	char *zErrMsg = 0;
	res = sqlite3_exec(db, sql, 0, 0, &zErrMsg);
	if (res == SQLITE_OK) {
		cout << "success";
	}
	else {
		cout << "fail:" << zErrMsg << endl;
		sqlite3_free(zErrMsg);
	}

	sqlite3_close(db);

	system("pause");
	return 0;
}