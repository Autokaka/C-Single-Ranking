#include "stdafx.h"



#include <iostream>
using namespace std;
#include "TicTacToe.h"

int main()
{ 
	TicTacToe round;
	round.pvpMode();

	return 0;
}