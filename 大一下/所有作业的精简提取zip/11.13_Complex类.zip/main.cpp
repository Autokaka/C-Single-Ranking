#include <iostream>
using namespace std;
#include "Complex.h"


int main()
{
	Complex x;
	Complex y;
	Complex z;

	cout << "��������x��";
	cin >> x;
	cout << "��������y��";
	cin >> y;

	cout << "__________��ǰ__________\n";
	cout << "x��" << x << endl;
	cout << "y��" << y << endl;
	cout << "z��" << z << endl;

	z = x + y;
	cout << "\n__________z = x + y__________\n";
	cout << z << " = " << x << " + " << y << endl;

	z = x - y;
	cout << "\n__________z = x - y__________\n";
	cout << z << " = " << x << " - " << y << endl;

	z = x * y;
	cout << "\n__________z = x * y__________\n";
	cout << z << " = " << x << " * " << y << endl;

	cout << "\n__________x == y��__________\n";
	if (x == y)
		cout << "�N!";
	else
		cout << "���N!";
	cout << endl;

	cout << "\n__________x != y��__________\n";
	if (x != y)
		cout << "�N!";
	else
		cout << "���N!";
	cout << endl;

	system("pause");
    return 0;
}
